package com.CustomerFeedback.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CustomerFeedback.Entity.Feedback;


import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
}


