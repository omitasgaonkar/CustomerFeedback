package com.CustomerFeedback.Controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.CustomerFeedback.Entity.Feedback;
import com.CustomerFeedback.Services.FeedbackService;

@Controller
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;

    // Display feedback form
    @GetMapping("/feedbackForm")
    public String showFeedbackForm(Model model) {
        model.addAttribute("feedback", new Feedback());
        return "feedbackForm";
    }

    // Add feedback
    @PostMapping("/submitFeedback")
    public String addFeedback(@ModelAttribute Feedback feedback) {
        feedbackService.addFeedback(feedback);
        return "redirect:/feedbackList";
    }

    // Display feedback list
    @GetMapping("/feedbackList")
    public String showFeedbackList(Model model) {
        model.addAttribute("feedbackList", feedbackService.getAllFeedback());
        return "feedbackList";
    }
}


