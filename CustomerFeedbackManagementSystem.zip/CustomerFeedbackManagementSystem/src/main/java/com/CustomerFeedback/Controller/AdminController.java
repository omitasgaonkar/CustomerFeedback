package com.CustomerFeedback.Controller;

import java.text.DecimalFormat;
import java.util.Map;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.CustomerFeedback.Entity.Feedback;
import com.CustomerFeedback.Repository.FeedbackRepository;

@Controller
public class AdminController {

    @Autowired
    private FeedbackRepository feedbackRepository;

    @GetMapping("/admin/feedbacks")
    public String getAdminDashboard(Model model) {
        List<Feedback> feedbackList = feedbackRepository.findAll();
        long totalFeedbacks = feedbackList.size();
        double averageRating = feedbackList.stream().mapToInt(Feedback::getRating).average().orElse(0.0);

        // Format the average rating to 1 decimal place
        DecimalFormat decimalFormat = new DecimalFormat("#.#");
        String formattedAverageRating = decimalFormat.format(averageRating);

        Map<Integer, Long> ratingDistribution = feedbackList.stream()
            .collect(Collectors.groupingBy(Feedback::getRating, Collectors.counting()));

        model.addAttribute("totalFeedbacks", totalFeedbacks);
        model.addAttribute("averageRating", formattedAverageRating);
        model.addAttribute("ratingDistribution", ratingDistribution);
        
        return "adminDashboard";
    }
}
