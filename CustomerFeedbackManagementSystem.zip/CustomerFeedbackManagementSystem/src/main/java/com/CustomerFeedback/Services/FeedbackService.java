package com.CustomerFeedback.Services;



import java.util.List;

import com.CustomerFeedback.Entity.Feedback;

public interface FeedbackService {
    void addFeedback(Feedback feedback);
    List<Feedback> getAllFeedback();
}

