package com.CustomerFeedback;


import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CustomerFeedback.Entity.Feedback;
import com.CustomerFeedback.Repository.FeedbackRepository;
import com.CustomerFeedback.Services.FeedbackServiceImpl;

import java.util.Arrays;
import java.util.List;

class FeedbackServiceImplTest {

    @Mock
    private FeedbackRepository feedbackRepository;

    @InjectMocks
    private FeedbackServiceImpl feedbackService;

    private Feedback feedback;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        feedback = new Feedback();
        feedback.setName("John Doe");
        feedback.setEmail("john.doe@example.com");
        feedback.setFeedbackText("Great service!");
        feedback.setRating(5);
    }

    @Test
    void addFeedback_ShouldSaveFeedback() {
        when(feedbackRepository.save(any(Feedback.class))).thenReturn(feedback);

        feedbackService.addFeedback(feedback);

        verify(feedbackRepository, times(1)).save(feedback);
    }

    @Test
    void getAllFeedback_ShouldReturnListOfFeedback() {
        List<Feedback> feedbackList = Arrays.asList(feedback);
        when(feedbackRepository.findAll()).thenReturn(feedbackList);

        List<Feedback> result = feedbackService.getAllFeedback();

        assertEquals(1, result.size());
        assertEquals("John Doe", result.get(0).getName());
    }
}

