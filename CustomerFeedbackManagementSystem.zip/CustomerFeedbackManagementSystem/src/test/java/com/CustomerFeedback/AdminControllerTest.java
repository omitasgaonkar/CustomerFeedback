package com.CustomerFeedback;



import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.boot.test.context.SpringBootTest;
import com.CustomerFeedback.Controller.AdminController;
import com.CustomerFeedback.Entity.Feedback;
import com.CustomerFeedback.Repository.FeedbackRepository;

import java.util.Arrays;

@SpringBootTest
public class AdminControllerTest {

    private MockMvc mockMvc;

    @Mock
    private FeedbackRepository feedbackRepository;

    @InjectMocks
    private AdminController adminController;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(adminController).build();
    }

    @Test
    void getAdminDashboard_ShouldReturnAdminDashboardPage() throws Exception {
        Feedback feedback = new Feedback();
        feedback.setRating(5);
        when(feedbackRepository.findAll()).thenReturn(Arrays.asList(feedback));

        mockMvc.perform(get("/admin/feedbacks"))
            .andExpect(status().isOk())
            .andExpect(view().name("adminDashboard"))
            .andExpect(model().attributeExists("totalFeedbacks"))
            .andExpect(model().attributeExists("averageRating"))
            .andExpect(model().attributeExists("ratingDistribution"));
    }
}

